# wbc_blanco_j4
 
##Template Overrides Kategorie:

###wbcblogfields

Gibt in einem Kategorieblog die Customfields als Tab/Accordion aus. Die Variante lässt sich in den Parametern einstellen. Standard ist Accordion. 
Welche Custom Fields als Accordion / Tab ausgegeben werden sollen, kann man in den Parametern auswählen.
Die Custom Fields müssen mit dem Wert "Tabs" im Feld "Note" im jeweiligen Customfield gekennzeichnet werden.

Die Accordions / Tabs mit den Feldern werden unterhalb des Beitrag ausgegeben.
**zusätzliche Optionen Layout:
Akkordeon oder Tabs
Erstes Element offen
Custonfields die in den Tabs erscheinen sollen

**zusätzliche Optionen:
Einleitungstext kürzen
Weiterlesen für Leading Beiträge
Leadingbeiträge kürzen
Schlagworte verlinken

###wbcblogaccordion

Gibt die Einleitungs Beiträge einer Kategorie als Accordions aus. Über die Parameter kann man einstellen, ob der erste Betrag aufgeklappt sein soll.
**zusätzliche Optionen Layout:
Erstes Element offen

**zusätzliche Optionen: 
Akkordeon / Tab Titel
Schlagworte verlinken

###wbcblog
**zusätzlichen Optionen:
Einleitungstext kürzen
Customfields ausgeben
Weiterlesen für Leading Beiträge
Leadingbeiträge kürzen
Schlagworte verlinken

##Template overrides Beitrag

###accordiontab
Gibt Customfields eines Beitrags als Accordion oder Tab aus.


##Template Positionen 
--- neu 13.9.2024 C.Oerter ---
###content-right 
Damit kann ein Modul innerhalb der Beitragszeile rechts ausgerichtet angezeigt werden. Das Modul kann über ein Customfield im Beitrag ausgewählt werden. (Customfield muss manuuell angelegt werden.)
